var exec = require('cordova/exec');
module.exports = {
  getVoices: function (ok, err) { exec(ok, err, 'AllVoicesTTS', 'getVoices', []); },
  play: function (segs, i, ok, err) { exec(ok, err, 'AllVoicesTTS', 'play', [segs, i]); },
  stop: function () { exec(null, null, 'AllVoicesTTS', 'stop', []); },
  perm: function () { exec(null, null, 'AllVoicesTTS', 'perm', []); },
  synth: function (seg, ok, err) { exec(ok, err, 'AllVoicesTTS', 'synth', [seg]); },
  saveBegin: function (name, ok, err) { exec(ok, err, 'AllVoicesTTS', 'saveBegin', [name]); },
  saveChunk: function (id, buf, ok, err) { exec(ok, err, 'AllVoicesTTS', 'saveChunk', [id, buf]); },
  saveEnd: function (id, ok, err) { exec(ok, err, 'AllVoicesTTS', 'saveEnd', [id]); }
};
