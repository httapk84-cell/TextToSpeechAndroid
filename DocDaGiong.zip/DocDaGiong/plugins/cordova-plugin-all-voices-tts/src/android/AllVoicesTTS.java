package com.davi.allvoices;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import org.apache.cordova.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class AllVoicesTTS extends CordovaPlugin {
  private final Map<String, TextToSpeech> map = new HashMap<>();
  private final ExecutorService ex = Executors.newSingleThreadExecutor();
  private final Map<Integer, OutputStream> outs = new ConcurrentHashMap<>();
  private final AtomicInteger outId = new AtomicInteger(0);
  private volatile int token = 0;
  private volatile TextToSpeech cur;
  private volatile CountDownLatch curLatch;
  private boolean asked = false;

  private Context ctx() { return cordova.getActivity().getApplicationContext(); }

  private synchronized TextToSpeech get(String pkg) throws Exception {
    TextToSpeech t = map.get(pkg);
    if (t != null) return t;
    final CountDownLatch l = new CountDownLatch(1);
    final int[] st = {-1};
    TextToSpeech n = new TextToSpeech(ctx(), s -> { st[0] = s; l.countDown(); }, pkg.isEmpty() ? null : pkg);
    if (!l.await(10, TimeUnit.SECONDS) || st[0] != TextToSpeech.SUCCESS) { n.shutdown(); throw new Exception("Không khởi tạo được bộ đọc " + pkg); }
    map.put(pkg, n);
    return n;
  }

  private TextToSpeech prepare(JSONObject s) throws Exception {
    TextToSpeech t = get(s.optString("engine", ""));
    String vn = s.optString("voice", "");
    if (!vn.isEmpty()) {
      Set<Voice> vs = t.getVoices();
      if (vs != null) for (Voice v : vs) if (v.getName().equals(vn)) { t.setVoice(v); break; }
    }
    t.setSpeechRate((float) s.optDouble("rate", 1));
    t.setPitch((float) s.optDouble("pitch", 1));
    return t;
  }

  private void halt() {
    TextToSpeech t = cur; if (t != null) t.stop();
    CountDownLatch l = curLatch; if (l != null) l.countDown();
  }

  private void startSvc() {
    try {
      Intent i = new Intent(ctx(), KeepAliveService.class);
      if (Build.VERSION.SDK_INT >= 26) ctx().startForegroundService(i); else ctx().startService(i);
    } catch (Exception e) {}
  }
  private void stopSvc() { try { ctx().stopService(new Intent(ctx(), KeepAliveService.class)); } catch (Exception e) {} }

  private void send(CallbackContext cb, JSONObject o) {
    PluginResult r = new PluginResult(PluginResult.Status.OK, o);
    r.setKeepCallback(true);
    cb.sendPluginResult(r);
  }

  @Override
  public boolean execute(String a, CordovaArgs args, CallbackContext cb) throws JSONException {
    switch (a) {
      case "getVoices": cordova.getThreadPool().execute(() -> voices(cb)); return true;
      case "play": {
        final JSONArray segs = args.getJSONArray(0);
        final int start = args.getInt(1);
        final int gen = ++token;
        halt();
        PluginResult pr = new PluginResult(PluginResult.Status.NO_RESULT);
        pr.setKeepCallback(true);
        cb.sendPluginResult(pr);
        startSvc();
        ex.execute(() -> loop(segs, start, gen, cb));
        return true;
      }
      case "stop": token++; halt(); stopSvc(); cb.success(); return true;
      case "perm":
        if (Build.VERSION.SDK_INT >= 33 && !asked && !cordova.hasPermission("android.permission.POST_NOTIFICATIONS")) {
          asked = true;
          cordova.requestPermission(this, 1, "android.permission.POST_NOTIFICATIONS");
        }
        cb.success(); return true;
      case "synth": {
        final JSONObject s = args.getJSONObject(0);
        token++; halt();
        cordova.getThreadPool().execute(() -> synth(s, cb));
        return true;
      }
      case "saveBegin": {
        final String name = args.getString(0);
        cordova.getThreadPool().execute(() -> saveBegin(name, cb));
        return true;
      }
      case "saveChunk": {
        final int id = args.getInt(0);
        final byte[] d = args.getArrayBuffer(1);
        cordova.getThreadPool().execute(() -> {
          try { OutputStream o = outs.get(id); if (o == null) throw new Exception("Tệp đã đóng"); o.write(d); cb.success(); }
          catch (Exception e) { cb.error(String.valueOf(e.getMessage())); }
        });
        return true;
      }
      case "saveEnd": {
        final int id = args.getInt(0);
        cordova.getThreadPool().execute(() -> {
          try { OutputStream o = outs.remove(id); if (o != null) { o.flush(); o.close(); } stopSvc(); cb.success(); }
          catch (Exception e) { cb.error(String.valueOf(e.getMessage())); }
        });
        return true;
      }
    }
    return false;
  }

  private void voices(CallbackContext cb) {
    try {
      List<TextToSpeech.EngineInfo> es = get("").getEngines();
      JSONArray out = new JSONArray();
      for (TextToSpeech.EngineInfo e : es) {
        try {
          Set<Voice> vs = get(e.name).getVoices();
          if (vs == null) continue;
          for (Voice v : vs) {
            JSONObject o = new JSONObject();
            o.put("engine", e.name); o.put("engineLabel", e.label);
            o.put("name", v.getName()); o.put("lang", v.getLocale().toLanguageTag());
            o.put("offline", !v.isNetworkConnectionRequired());
            out.put(o);
          }
        } catch (Exception x) {}
      }
      cb.success(out);
    } catch (Exception e) { cb.error(String.valueOf(e.getMessage())); }
  }

  private void loop(JSONArray segs, int start, int gen, CallbackContext cb) {
    try {
      for (int i = start; i < segs.length() && gen == token; i++) {
        JSONObject s = segs.getJSONObject(i);
        TextToSpeech t = prepare(s);
        final CountDownLatch l = new CountDownLatch(1);
        t.setOnUtteranceProgressListener(new UtteranceProgressListener() {
          @Override public void onStart(String id) {}
          @Override public void onDone(String id) { l.countDown(); }
          @Override public void onError(String id) { l.countDown(); }
        });
        Bundle b = new Bundle();
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, (float) s.optDouble("volume", 1));
        cur = t; curLatch = l;
        if (gen != token) break;
        send(cb, new JSONObject().put("e", "seg").put("i", i));
        t.speak(s.getString("text"), TextToSpeech.QUEUE_FLUSH, b, "u" + i);
        l.await(10, TimeUnit.MINUTES);
      }
      if (gen == token) send(cb, new JSONObject().put("e", "end"));
    } catch (Exception e) {
      try { if (gen == token) send(cb, new JSONObject().put("e", "err").put("m", String.valueOf(e.getMessage()))); } catch (Exception x) {}
    } finally { if (gen == token) stopSvc(); }
  }

  // Tạo âm thanh WAV cho một đoạn, trả về ArrayBuffer cho JavaScript
  private void synth(JSONObject s, CallbackContext cb) {
    File f = null;
    try {
      TextToSpeech t = prepare(s);
      f = File.createTempFile("seg", ".wav", ctx().getCacheDir());
      final CountDownLatch l = new CountDownLatch(1);
      final boolean[] ok = {false};
      t.setOnUtteranceProgressListener(new UtteranceProgressListener() {
        @Override public void onStart(String id) {}
        @Override public void onDone(String id) { ok[0] = true; l.countDown(); }
        @Override public void onError(String id) { l.countDown(); }
      });
      Bundle b = new Bundle();
      b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, (float) s.optDouble("volume", 1));
      if (t.synthesizeToFile(s.getString("text"), b, f, "syn") != TextToSpeech.SUCCESS) throw new Exception("Bộ đọc từ chối tạo tệp âm thanh");
      if (!l.await(120, TimeUnit.SECONDS) || !ok[0]) throw new Exception("Không tạo được âm thanh cho đoạn này");
      ByteArrayOutputStream bo = new ByteArrayOutputStream();
      try (InputStream in = new FileInputStream(f)) {
        byte[] buf = new byte[65536]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
      }
      cb.success(bo.toByteArray());
    } catch (Exception e) {
      cb.error(String.valueOf(e.getMessage()));
    } finally { if (f != null) f.delete(); }
  }

  // Mở tệp để ghi: Android 10 trở lên lưu vào Download/DocDaGiong, bản cũ hơn lưu vào thư mục Music của ứng dụng
  private void saveBegin(String name, CallbackContext cb) {
    try {
      OutputStream o; String where;
      if (Build.VERSION.SDK_INT >= 29) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg");
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/DocDaGiong");
        Uri u = ctx().getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new Exception("Không tạo được tệp trong thư mục Tải xuống");
        o = ctx().getContentResolver().openOutputStream(u);
        where = "thư mục Download, mục DocDaGiong, tên tệp " + name;
      } else {
        File dir = ctx().getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (dir == null) throw new Exception("Không có bộ nhớ ngoài");
        dir.mkdirs();
        File f = new File(dir, name);
        o = new FileOutputStream(f);
        where = f.getAbsolutePath();
      }
      int id = outId.incrementAndGet();
      outs.put(id, new BufferedOutputStream(o, 65536));
      startSvc();
      cb.success(new JSONObject().put("id", id).put("where", where));
    } catch (Exception e) { cb.error(String.valueOf(e.getMessage())); }
  }

  @Override
  public void onDestroy() {
    token++; halt(); stopSvc();
    for (OutputStream o : outs.values()) { try { o.close(); } catch (Exception e) {} }
    for (TextToSpeech t : map.values()) t.shutdown();
    ex.shutdownNow();
  }
}
