package com.davi.allvoices;

import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

public class KeepAliveService extends Service {
  @Override public IBinder onBind(Intent i) { return null; }

  @Override public int onStartCommand(Intent in, int flags, int id) {
    String ch = "tts";
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationManager nm = getSystemService(NotificationManager.class);
      nm.createNotificationChannel(new NotificationChannel(ch, "Đang đọc", NotificationManager.IMPORTANCE_LOW));
    }
    Intent li = getPackageManager().getLaunchIntentForPackage(getPackageName());
    PendingIntent pi = PendingIntent.getActivity(this, 0, li, PendingIntent.FLAG_IMMUTABLE);
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ch) : new Notification.Builder(this);
    b.setContentTitle("Đọc Đa Giọng").setContentText("Đang đọc văn bản")
     .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi);
    if (Build.VERSION.SDK_INT >= 29) startForeground(1, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    else startForeground(1, b.build());
    return START_NOT_STICKY;
  }
}
