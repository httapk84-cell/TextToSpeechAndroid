Cách tạo APK:
1. Tạo kho GitHub mới, tải toàn bộ nội dung thư mục này lên (giữ nguyên thư mục .github).
2. Đẩy lên nhánh main. GitHub Actions tự dựng APK.
3. Tải app-debug.apk ở mục Releases hoặc Artifacts, cài vào điện thoại.
Cách viết vai:  Tên vai: lời thoại   (mỗi vai một dòng)

Xuất MP3: nhấn "Xuất ra MP3" trong ứng dụng. Tệp lưu ở Download/DocDaGiong (Android 10 trở lên).
Bộ mã hóa MP3 là lamejs (giấy phép LGPL-3.0, xem www/LAMEJS-LICENSE.txt).
